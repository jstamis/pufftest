describe('base testing', () => {
  beforeEach(() => {
    cy.visit('/index.html', {
      onBeforeLoad(win) {
        cy.spy(win.console, 'log').as('consoleLog');
      },
    });
  });

  it('checks the home page', () => {
    cy.log('checking the home page and get to map page');
    cy.visit('/home');
    cy.get('.c-logo')
      .should('be.visible')
      .and('have.attr', 'alt');
    cy.get('[href="/sign-in"]')
      .should('have.text', 'Sign In');
    cy.log('should have two buttons for sign up');
    cy.get('button')
      .should('have.length', 2);
    cy.get('button')
      .contains('Order now!')
      .click();
    cy.url().should('include', '/address');
  });
  it('checks sign in page', () => {
    cy.log('checking the sign in');
    cy.visit('/sign-in');
    cy.get('.logo')
      .should('be.visible');
    cy.get('.slogan-top-text')
      .should('have.text', 'We don’t judge');
    cy.get('.slogan-bottom-text')
      .should('have.text', 'We Deliver');
    cy.contains('Enter Mobile Number')
      .should('be.visible');
    cy.contains('Continue with Facebook')
      .should('be.visible');
    cy.contains('Return Policy')
      .should('have.attr', 'href');
    cy.get('[href="/home/return-policy"]')
      .should('be.visible');
    cy.get('[href="/home/terms-and-conditions"]')
      .should('be.visible');
    cy.get('.copyright-text')
      .should('have.text', '© GoBrands Inc.');
  });
  it('searches for a product to order', () => {
    cy.visit('/store');
    cy.url().should('include', '/store');
    cy.get('#product-search').type('Soylent');
    cy.get('[alt="Soylent Cafe Mocha 14 oz"]').click();
    cy.url().should('include', '/#product/soylent_cafe_mocha_14_oz');
    cy.get('.product-desc')
      .should('have.text', 'Breakfast and coffee in one. Two birds one stone.');
    cy.get('button')
      .contains('Add')
      .click();
  });
});
