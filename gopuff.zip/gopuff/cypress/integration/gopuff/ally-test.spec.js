// Cypress/integration/a11y.spec.js
describe('Accessibility checks', () => {
  function setUpAxe(path) {
    cy.visit(path);
    cy.injectAxe(); // make sure axe is available on the page
  }
  it('Home page has no detectable a11y violations on load', () => {
    setUpAxe('/home');
    cy.checkA11y(); // fail for a11y violations
  });
  it('sign-in page has no detectable a11y violations on load', () => {
    setUpAxe('/sign-in');
    cy.checkA11y(); // fail for a11y violations
  });
  it('about us page has no detectable a11y violations on load', () => {
    setUpAxe('/about-us');
    cy.checkA11y(); // fail for a11y violations
  });
  it('shop page has no detectable a11y violations on load', () => {
    setUpAxe('/#shop');
    cy.checkA11y(); // fail for a11y violations
  });
});
