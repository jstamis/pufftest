const xkcdData = require('../../fixtures/xkcd');

describe('api tests', () => {
  beforeEach(() => {
    cy.request('http://xkcd.com/1500/info.0.json').as('xkcdComic');
  });
  it('checks xkcd', () => {
    cy.get('@xkcdComic')
      .its('headers')
      .its('content-type')
      .should('include', 'application/json');
  });
  it('checks the status code', () => {
    cy.get('@xkcdComic')
      .its('status')
      .should('equal', 200);
  });
  it('checks xkcd content', () => {
    cy.get('@xkcdComic')
      .its('body')
      .should('deep.eq', xkcdData);
  });
  it('returns a 404 when comic is not available', () => {
    cy.request({ url: 'http://xkcd.com/5500/info.0.json', failOnStatusCode: false })
      .its('status')
      .should('be', 404);
  });
});
