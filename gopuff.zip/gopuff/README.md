navigate to the gopuff directory in a terminal
use `npm i`
options to run test and linter:

run `npm run test` to run the available tests headless
run `npm run debug` to open the test runner and pick one or all tests
run `npm run lint` to lint the spec files in the integration folder